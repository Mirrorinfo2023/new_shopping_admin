export default {
  ccompany_id: "67e920003c16eb613ed5e8a9",
};
