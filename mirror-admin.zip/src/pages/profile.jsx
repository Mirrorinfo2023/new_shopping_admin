const profile = () => {
    return (
        <>
            Hello from 
            profile 
        </>
    )
}

export default profile;